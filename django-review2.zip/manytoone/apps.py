from django.apps import AppConfig


class ManytooneConfig(AppConfig):
    name = 'manytoone'
